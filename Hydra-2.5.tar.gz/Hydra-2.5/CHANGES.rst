=========
Changelog
=========

2.5 (2016-08-02)
----------------

- Close descriptor file in Reading/UpdatingBloomFilter.

- Define some BloomFilter and MMapBitField methods as cpdef.

2.4 (2016-08-02)
----------------

- #12, #15: Ship C code to avoid Cython install time dependency.

2.3 (2015-06-04)
----------------

- Look at Git commit history for changes.
